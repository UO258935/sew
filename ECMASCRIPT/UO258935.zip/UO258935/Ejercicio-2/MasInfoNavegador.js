document.write(
    "<p>" + ObjInfoNavegador.version_navegador + "</p>",
    "<p>" + ObjInfoNavegador.plataforma_navegador + "</p>",
    "<p>" + ObjInfoNavegador.vendedor_navegador + "</p>",
    "<p>" + ObjInfoNavegador.agente_navegador + "</p>"
);
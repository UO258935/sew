document.write(
    "<h2>" + objetoTarea3.nombre_titulacion + "</h2>"
);
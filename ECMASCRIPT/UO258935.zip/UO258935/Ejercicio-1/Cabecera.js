var tarea3 = {
    informacion_asignatura: "Software y estándares en la Web",
    nombre_titulacion: "Grado en Ingeniería Informática del Software",
    nombre_centro: "Escuela Ingeniería Informática",
    nombre_universidad: "Universidad de Oviedo",
    curso_actual: "2019-2020",
    nombre_estudiante: "Marcos Matilla",
    email: "UO258935@uniovi.es"
}

var objetoTarea3 = Object.create(tarea3);
document.write(
    "<h3>" + objetoTarea3.nombre_centro + "</h3>"
);
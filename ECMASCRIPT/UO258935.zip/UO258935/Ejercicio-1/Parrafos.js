document.write(
    "<p>" + objetoTarea3.curso_actual + "</p>",
    "<p>" + objetoTarea3.nombre_estudiante + "</p>",
    "<p>" + objetoTarea3.email + "</p>"
);
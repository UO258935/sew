document.write(
    "<h1>" + objetoTarea3.informacion_asignatura + "</h1>"
);
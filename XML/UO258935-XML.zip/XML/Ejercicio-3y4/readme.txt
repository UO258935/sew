UO258935
Marcos Matilla González
Lenguaje: C#
Versión del compilador: Visual Studio Community 2017
Archivos: ConsoleApp1\bin\Release
Instrucciones de uso:
	-Genera distintos tipos de XML relacionados con rutinas de gimnasios.
	-Lista los distintos tipos de XML generados.